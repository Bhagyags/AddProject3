package com.example.demo.entity;

public class Laptop 
{
	int srlno;
	String brand;
	int cost;
	public Laptop() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Laptop(int srlno, String brand, int cost) {
		super();
		this.srlno = srlno;
		this.brand = brand;
		this.cost = cost;
	}
	public int getSrlno() {
		return srlno;
	}
	public void setSrlno(int srlno) {
		this.srlno = srlno;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Laptop [srlno=" + srlno + ", brand=" + brand + ", cost=" + cost + "]";
	}
	
	

}
