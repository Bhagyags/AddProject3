package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;

@RestController
@RequestMapping("/crud")
public class CrudController 
{
	@GetMapping(value="{empId}")
	public static Employee getInfo(@PathVariable int empId)
	{
		Employee ep=new Employee(empId,"Ajay",12200);
		return ep;
	}

}
