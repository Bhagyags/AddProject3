package com.example.demo.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dc")
public class DataController 
{
	@PostMapping
	public String acceptData(@RequestParam String data1,@RequestParam int data2,@RequestParam int data3,@RequestParam int data4,@RequestParam int data5,@RequestParam int data6)
	{
		return (data1+" percentage is:"+(data2+data3+data4+data5+data6/500)*100);
	}

}
