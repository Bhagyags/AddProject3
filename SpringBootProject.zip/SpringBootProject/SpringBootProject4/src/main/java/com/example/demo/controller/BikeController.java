package com.example.demo.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Bike;

@RestController
@RequestMapping("/Bike")
public class BikeController
{
	Bike bk;
	@PostMapping
	public String createBike(@RequestBody Bike bk)
	{
		this.bk=bk;
		return "Bike data created";
	}
	
	@GetMapping(value="{eng_no}")
	public Bike readBike(@PathVariable String eng_no)
	{
		return bk;
	}
	
	@PutMapping
	public String updateBike(@RequestBody Bike bk)
	{
		this.bk=bk;
		return "Bike data updated";
	}
	
	@DeleteMapping(value="{eng_no}")
	public String delteBike(@PathVariable String eng_no)
	{
		bk=null;
		return "Bike object is deleted"; 
	}

}
