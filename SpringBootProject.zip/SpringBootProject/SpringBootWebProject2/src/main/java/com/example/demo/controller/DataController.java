package com.example.demo.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dc1")
public class DataController 
{
	@PostMapping
     public String acceptData(@RequestParam String data1,@RequestParam String data2,@RequestParam String data3,@RequestParam String data4,@RequestParam String Date,@RequestParam String Month,@RequestParam String Year,@RequestParam int data5)
     {
		return("user name is: "+data1+"\n"+"emailid is:"+data2+"\n"+"password is: "+data3+"\n"+"Gender is:"+data4+"\n"+"Dob is: "+Date+Month+Year+"\n"+"phone no is: "+data5);
     }
}
